=== OmiBeaver Booking ===
Contributors: omiBeaver
Tags: woocommerce, rest, booking,api,gym

Adds a plugin for Virtual goods course reservations Rest API and admin manage pane.

== Description ==

Adds a plugin for Virtual goods course reservations Rest API and admin manage pane.


== Upgrade Notice ==


= 0.1 =
Initial Release

1.支持token登录
2.支持服务端生成订单
3.支持预约记录查询
4.支持预约状态更改
5.支持新增预约
6.支持API注册
7.管理后台支持预约管理与更新查询

