### OmiBeaver Booking ###
Contributors: omiBeaver

Author winter_986@qq.com

Auth home http://apps.wa-jjr.top

Tags: woocommerce, rest, booking,api,gym

Adds a plugin for Virtual goods course reservations Rest API and admin manage pane.

## Description 

Adds a plugin for Virtual goods course reservations Rest API and admin manage pane.


## Upgrade Notice 


### v1.0.1 
Initial Release

